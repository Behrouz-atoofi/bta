package com.mapsa.bta.controller;

import com.mapsa.bta.services.loginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.SQLException;

@Controller
public class HomeController {

    @RequestMapping("/")
    public String gotoIndex() {
        return "index" ;
    }
    @RequestMapping("/login")
    public String gotoLogin() {
        return "login" ;
    }
    @Autowired
    private loginService loginService ;
    @RequestMapping("/loginUser")
    public String loginUser(@RequestParam String email,@RequestParam String password) throws SQLException {

        if (loginService.Authenticate(email, password))
            return "index" ;
        return "login" ;
    }

    @RequestMapping("/registerUSer")
    public String registerUSer() {
        return "login" ;
    }





}
